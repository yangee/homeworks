#include <stdio.h>
int main()
{
   printf("Value of EOF is %d\n", EOF);
   return 0;
}