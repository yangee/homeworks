#include<stdio.h>
int add(int x, int y)
{
    return x+y;
}

int main()
{
    printf("%d",add(4,3));
    return 0;
}