#include<stdio.h>

int main()
{
    float fahr, celsius;
    int lower, upper, step;
    lower = 0;
    upper = 300;
    step = 20;
    printf("Celsius to Farenheit\n");
    printf("\n");

    for(celsius=lower;celsius<=upper;celsius= celsius + step){
// careful 5/9 is calculated as 0 in int division.
        fahr = celsius*1.8 + 32;
        printf("%3.0f\t%6.1f\n", celsius,fahr);  
    }
    return 0;
}