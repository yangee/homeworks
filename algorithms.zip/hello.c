#include<stdio.h>

// int(output type) main(fucntion name) (void)(input parameter type and name)
int main()
{
    printf("Hello world.");
return 0;
}