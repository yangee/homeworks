#include<stdio.h>
#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))  
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))  
int max(int a,int b){
    int max_val;
    if(a>b){
        max_val = a;
    }
    else{
        max_val = b;
    }
    return max_val;
}
int linear_runtime(int const * const data, int n)
{   
    int i;
    int max_overall = data[0];
    int max_ending_here = data[0];
    for (i=1;i<n;i++){
        max_ending_here = MAX(data[i],max_ending_here+data[i]);
        max_overall = MAX(max_overall,max_ending_here); 
    }
    printf("%d\n",max_overall);
	return 0;
}
int quadratic_runtime(int const * const data, int n)
{
    int i,j,sum;
    int max_overall = 0;

    for(i=0;i<n;i++){
        sum = data[i];
        for(j=i+1;j<n;j++){
            sum += data[j];   
        if(sum>max_overall) max_overall = sum;
        }
        if(i==n-1){
            if(sum>max_overall) max_overall = sum;
        }
        
    }
    printf("%d\n",max_overall);
	return 0;
}
int main()
{   
    int data[] = {1,-3,4,5,10,-100,1000};
    int n = 7;
    quadratic_runtime(data,n);
    linear_runtime(data,n);
    return 0;
}