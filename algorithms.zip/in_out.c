#include<stdio.h>
int main()
{
    int c;
    while((c=getchar()) !=EOF){
        putchar(c);
    }
}

/*
int main()
{
    int c;
    c = getchar(); 
    while(c != EOF){
        putchar(c);
        c = getchar();
        //Ctrl+c EOF.or #define EOF -1(0)
    }
    return 0;
}
*/
