#include<stdio.h>
int sum_two(int a, int b){
    return a+b;
}

int main() {

	// This code tests your summer function.
	// You should not modify this code.

	int total;
	total = sum_two(10, 20);
	printf("Expected Output: %d\n", 30);
	printf("Received Output: %d\n", total);
	if (total == 30) {
		return 0;
	} else {
		return 1;
	}
}