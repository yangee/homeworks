a = input()
type(a)